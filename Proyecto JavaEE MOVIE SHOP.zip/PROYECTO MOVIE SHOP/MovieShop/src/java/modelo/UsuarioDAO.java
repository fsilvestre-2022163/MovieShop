package modelo;

import config.Conexion;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

public class UsuarioDAO {

    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;

    public Usuario validar(String usuario, String pass) {
        Usuario usua = new Usuario();
        String sql = "select * from Usuarios where usuario = ? and pass = ? ";
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, pass);
            rs = ps.executeQuery();
            while (rs.next()) {
                usua.setIdUsuario(rs.getInt("idUsuario"));
                usua.setNombreUsuario(rs.getString("nombreUsuario"));
                usua.setApellidoUsuario(rs.getString("apellidoUsuario"));
                usua.setUsuario(rs.getString("usuario"));
                usua.setPass(rs.getString("pass"));
                usua.setEmail(rs.getString("email"));

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return usua;
    }

    // Agregar Usuario
    public int Agregar(Usuario u) {
        String sql = "insert into Usuarios(nombreUsuario, apellidoUsuario, usuario, pass, email, fotoPerfil) values(?,?,?,?,?,?)";
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, u.getNombreUsuario());
            ps.setString(2, u.getApellidoUsuario());
            ps.setString(3, u.getUsuario());
            ps.setString(4, u.getPass());
            ps.setString(5, u.getEmail());
            ps.setBlob(6, u.getFotoPerfil());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resp;
    }

    public List listar() {
        String sql = "Select * from Usuarios";
        List<Usuario> listaUsuario = new ArrayList<>();
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Usuario usua = new Usuario();
                usua.setIdUsuario(rs.getInt(1));
                usua.setNombreUsuario(rs.getString(2));
                usua.setApellidoUsuario(rs.getString(3));
                usua.setUsuario(rs.getString(4));
                usua.setPass(rs.getString(5));
                usua.setEmail(rs.getString(6));
                listaUsuario.add(usua);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaUsuario;
    }
    public Usuario listarIdUsuario(int id) {
        Usuario usua = new Usuario();
        String sql = "select * from Usuario where idUsuario=" + id;
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                usua.setIdUsuario(rs.getInt(1));
                usua.setNombreUsuario(rs.getString(2));
                usua.setApellidoUsuario(rs.getString(3));
                usua.setUsuario(rs.getString(4));
                usua.setPass(rs.getString(5));
                usua.setEmail(rs.getString(6));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return usua;
    }
    public void listarImg(int id, HttpServletResponse response){
        String sql="select * from Usuarios where idUsuario="+id;
        InputStream inputStream=null;
        OutputStream outputStream=null;
        BufferedInputStream bufferedInputStream=null;
        BufferedOutputStream bufferedOutputStream =null;
        response.setContentType("image/*");
        try {
            outputStream = response.getOutputStream();
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            if(rs.next()){
                inputStream=rs.getBinaryStream("fotoPerfil");                 
            }
            bufferedInputStream=new BufferedInputStream(inputStream);
            bufferedOutputStream=new BufferedOutputStream(outputStream);
            int i=0;
            while((i=bufferedInputStream.read())!=-1){
                bufferedOutputStream.write(i);
            }
        } catch (Exception e) {
        }       
    }
}
