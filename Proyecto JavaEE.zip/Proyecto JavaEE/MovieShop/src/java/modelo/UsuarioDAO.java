package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UsuarioDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    // Agregar Usuario
    public int Agregar(Usuario u){
        String sql = "insert into Usuarios(nombreUsuario, apellidoUsuario, usuario, pass, email, fotoPerfil) values(?,?,?,?,?,?)";
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, u.getNombreUsuario());
            ps.setString(2, u.getApellidoUsuario());
            ps.setString(3, u.getUsuario());
            ps.setString(4, u.getPass());
            ps.setString(5, u.getEmail());
            ps.setByte(6, u.getFotoPerfil());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resp;
    }
}
