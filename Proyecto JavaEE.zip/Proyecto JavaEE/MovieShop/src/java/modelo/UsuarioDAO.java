package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UsuarioDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    public Usuario validar(String usuario, String pass ) {
        Usuario usua =new Usuario();
        String sql = "select * from Usuarios where usuario = ? and pass = ? ";
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, pass);
            rs = ps.executeQuery();
            while (rs.next()) {
                usua.setIdUsuario(rs.getInt("idUsuario"));
                usua.setNombreUsuario(rs.getString("nombreUsuario"));
                usua.setApellidoUsuario(rs.getString("apellidoUsuario"));
                usua.setUsuario(rs.getString("usuario"));
                usua.setPass(rs.getString("pass"));
                usua.setEmail(rs.getString("email"));
               
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return usua;
    }
    // Agregar Usuario
    public int Agregar(Usuario u){
        String sql = "insert into Usuarios(nombreUsuario, apellidoUsuario, usuario, pass, email, fotoPerfil) values(?,?,?,?,?,?)";
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, u.getNombreUsuario());
            ps.setString(2, u.getApellidoUsuario());
            ps.setString(3, u.getUsuario());
            ps.setString(4, u.getPass());
            ps.setString(5, u.getEmail());
            ps.setByte(6, u.getFotoPerfil());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resp;
    }
}
