
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import modelo.Cesta;
import modelo.CestaDAO;
import modelo.DetallePago;
import modelo.DetallePagoDAO;
import modelo.DetallePromocion;
import modelo.DetallePromocionDAO;
import modelo.Pago;
import modelo.PagoDAO;
import modelo.Producto;
import modelo.ProductoDAO;
import modelo.Promocion;
import modelo.PromocionDAO;
import modelo.Proveedores;
import modelo.ProveedoresDAO;
import modelo.Resena;
import modelo.ResenaDAO;
import modelo.ServicioCliente;
import modelo.ServicioClienteDAO;
import modelo.TipoTarjeta;
import modelo.TipoTarjetaDAO;
import modelo.Usuario;
import modelo.UsuarioDAO;

/**
 *
 * @author 50242
 */
@WebServlet(name = "Controlador", urlPatterns = {"/Controlador"})
@MultipartConfig
public class Controlador extends HttpServlet {
    
    int idProducto;
    int codProveedor;
    int idCesta;
    int idResena;
    int idDetallePromocion;

    Usuario usuario = new Usuario();
    UsuarioDAO usuarioDAO = new UsuarioDAO();
    int idUsuario;
    Promocion promocion = new Promocion();
    PromocionDAO promocionDao = new PromocionDAO();
    Cesta cesta = new Cesta();
    CestaDAO cestaDAO = new CestaDAO();
    Resena resena = new Resena();
    ResenaDAO resenaDAO = new ResenaDAO();
    DetallePromocion detallePromocion = new DetallePromocion();
    DetallePromocionDAO detallePromocionDAO = new DetallePromocionDAO();
    Producto producto = new Producto();
    ProductoDAO productoDAO = new ProductoDAO();
    Pago pago = new Pago();
    PagoDAO pagoDAO = new PagoDAO();
    TipoTarjeta tipoTarjeta = new TipoTarjeta();
    TipoTarjetaDAO tipoTarjetaDAO = new TipoTarjetaDAO();
    DetallePago detallePago = new DetallePago();
    DetallePagoDAO detallePagoDao = new DetallePagoDAO();
    ServicioCliente servicioCliente = new ServicioCliente();
    ServicioClienteDAO servicioClienteDAO = new ServicioClienteDAO();
    Proveedores proveedores = new Proveedores();
    ProveedoresDAO proveedoresDAO = new ProveedoresDAO();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");

        if (menu.equals("PrincipalAdmin")) {
            request.getRequestDispatcher("PrincipalAdmin.jsp").forward(request, response);
        } else if (menu.equals("Index")) {
            request.getRequestDispatcher("index.jsp").forward(request, response);
        } else if (menu.equals("AgregarUsuarios")) {
            request.getRequestDispatcher("AgregarUsuarios.jsp").forward(request, response);
        } else if (menu.equals("Facebook")) {
            request.getRequestDispatcher("Facebook.jsp").forward(request, response);
        } else if (menu.equals("Google")) {
            request.getRequestDispatcher("Google.jsp").forward(request, response);
        } else if (menu.equals("Principal")) {
            request.getRequestDispatcher("Principal.jsp").forward(request, response);
        } else if (menu.equals("Peliculas")) {
            request.getRequestDispatcher("Peliculas.jsp").forward(request, response);
        } else if (menu.equals("Usuario")) {
            switch (accion) {
                case "Listar":
                    List listaUsuario = usuarioDAO.listar();
                    request.setAttribute("usuarios", listaUsuario);
                    break;
                case "Agregar":
                    String nombreUsuario = request.getParameter("txtNombres");
                    String apellidoUsuario = request.getParameter("txtApellidos");
                    String usua = request.getParameter("txtUsuario");
                    String pass = request.getParameter("txtPass");
                    String email = request.getParameter("txtEmail");
                    Part part = request.getPart("imgFotoPerfil");
                    InputStream inputStream = part.getInputStream();
                    usuario.setNombreUsuario(nombreUsuario);
                    usuario.setApellidoUsuario(apellidoUsuario);
                    usuario.setUsuario(usua);
                    usuario.setPass(pass);
                    usuario.setEmail(email);
                    usuario.setFotoPerfil(inputStream);
                    usuarioDAO.Agregar(usuario);
                    break;
                case "Editar":

                    break;
                case "Actualizar":

                    break;
                case "Eliminar":

                    break;
            }
            request.getRequestDispatcher("index.jsp").forward(request, response);

        } else if (menu.equals("Producto")) {
            switch (accion) {
                case "Listar":
                    List<Producto> listaProducto = productoDAO.listar();
                    request.setAttribute("productos", listaProducto);
                    List listaDeProveedores = proveedoresDAO.listar();
                    request.setAttribute("proveedores", listaDeProveedores);
                    /*List listaProveedor=productoDAO.listarProveedores();
                    request.setAttribute("proveedores", listaProveedor);*/
                    break;
                case "Agregar":
                    //System.out.println("Hola James");                    
                    String nombreProducto = request.getParameter("txtNombreProducto");
                    String genero = request.getParameter("txtGenero");
                    String categoria = request.getParameter("txtCategoria");
                    Double precio = Double.parseDouble(request.getParameter("txtPrecio"));
                    String duracion = request.getParameter("txtDuracion");
                    String sinopsis = request.getParameter("txtSinopsis");
                    Part part = request.getPart("imgPortada");
                    InputStream inputStream = part.getInputStream();
                    int idProveedor;
                    idProveedor = Integer.parseInt(request.getParameter("cmbIdProveedor"));

                    producto.setNombreProducto(nombreProducto);
                    producto.setGenero(genero);
                    producto.setCategoria(categoria);
                    producto.setPrecio(precio);
                    producto.setDuracion(duracion);
                    producto.setSinopsis(sinopsis);
                    producto.setPortada(inputStream);
                    producto.setIdProveedor(idProveedor);
                    productoDAO.agregar(producto);
                    
                    request.getRequestDispatcher("Controlador?menu=Producto&accion=Listar").forward(request, response);
                    break;
                case "Editar":
                    idProducto = Integer.parseInt(request.getParameter("idProducto"));
                    Producto p = productoDAO.listarIdProducto(idProducto);
                    request.setAttribute("productoEncontrado", p);
                    request.getRequestDispatcher("Controlador?menu=Producto&accion=Listar").forward(request, response);
                    break;
                case "Actualizar":
                    System.out.println("Hola");
                    
                    String nombreProd = request.getParameter("txtNombreProducto");
                    String generoProd = request.getParameter("txtGenero");
                    String categoriaProd = request.getParameter("txtCategoria");
                    Double precioProd = Double.parseDouble(request.getParameter("txtPrecio"));
                    String duracionProd = request.getParameter("txtDuracion");
                    String sinopsisProd = request.getParameter("txtSinopsis");
                    Part partProd = request.getPart("imgPortada");
                    InputStream inputStreamProd = partProd.getInputStream();
                    int idProveedorProd;
                    idProveedorProd = Integer.parseInt(request.getParameter("cmbIdProveedor"));

                    producto.setNombreProducto(nombreProd);
                    producto.setGenero(generoProd);
                    producto.setCategoria(categoriaProd);
                    producto.setPrecio(precioProd);
                    producto.setDuracion(duracionProd);
                    producto.setSinopsis(sinopsisProd);
                    producto.setPortada(inputStreamProd);
                    producto.setIdProveedor(idProveedorProd);
                    producto.setIdProducto(idProducto);                    
                    productoDAO.actualizar(producto);
                    
                   /* System.out.println(nombreProd);
                    System.out.println(generoProd);
                    System.out.println(categoriaProd);
                    System.out.println(precioProd);
                    System.out.println(duracionProd);
                    System.out.println(sinopsisProd);
                    System.out.println(inputStreamProd);
                    System.out.println(idProveedorProd);
                    System.out.println(idProducto);*/
                    
                    request.getRequestDispatcher("Controlador?menu=Producto&accion=Listar").forward(request, response);
                    
                    break;
                case "Eliminar":
                    idProducto = Integer.parseInt(request.getParameter("idProducto"));
                    productoDAO.eliminar(idProducto);
                    request.getRequestDispatcher("Controlador?menu=Producto&accion=Listar").forward(request, response);

                    break;
            }
            request.getRequestDispatcher("Producto.jsp").forward(request, response);

        } else if (menu.equals("DetallePago")) {
            switch (accion) {
                case "Listar":
                    List litaDetallePagos = detallePagoDao.listar();
                    request.setAttribute("detallePagos", litaDetallePagos);
                    break;
                case "Agregar":

                    break;
                case "Editar":

                    break;
                case "Actualizar":

                    break;
                case "Eliminar":

                    break;
            }

            request.getRequestDispatcher("DetallePago.jsp").forward(request, response);

        } else if (menu.equals("Pago")) {
            switch (accion) {
                case "Listar":
                    List listaPago = pagoDAO.listar();
                    request.setAttribute("pagos", listaPago);
                    break;
                case "Agregar":

                    break;
                case "Editar":

                    break;
                case "Actualizar":

                    break;
                case "Eliminar":

                    break;
            }
            request.getRequestDispatcher("Pago.jsp").forward(request, response);

        } else if (menu.equals("TipoTarjeta")) {
            switch (accion) {
                case "Listar":
                    List listaTipoTarjeta = tipoTarjetaDAO.listar();
                    request.setAttribute("tipoTarjetas", listaTipoTarjeta);
                    break;
                case "Agregar":

                    break;
                case "Editar":

                    break;
                case "Actualizar":

                    break;
                case "Eliminar":

                    break;
            }
            request.getRequestDispatcher("TipoTarjeta.jsp").forward(request, response);

        } else if (menu.equals("ServicioCliente")) {
            switch (accion) {
                case "Listar":
                    List listarServicioCliente = servicioClienteDAO.listar();
                    request.setAttribute("servicioClientes", listarServicioCliente);
                    break;
                case "Agregar":

                    break;
                case "Editar":

                    break;
                case "Actualizar":

                    break;
                case "Eliminar":

                    break;
            }
            request.getRequestDispatcher("TablaServicioCliente.jsp").forward(request, response);

        } else if(menu.equals("Proveedores")){
          switch(accion){
              case "Listar":
                  List listaDeProveedores = proveedoresDAO.listar();
                  request.setAttribute("proveedores", listaDeProveedores);
                  break;
              case "Agregar":
                  String nombres = request.getParameter("txtNombres");
                  String telefono = request.getParameter("txtTelefono");
                  String email = request.getParameter("txtEmail");
                  proveedores.setNombreProveedor(nombres);
                  proveedores.setTelefonoProveedor(telefono);
                  proveedores.setEmail(email);
                  System.out.println(proveedores.getNombreProveedor());
                  System.out.println(proveedores.getTelefonoProveedor());
                  System.out.println(proveedores.getEmail());
                  proveedoresDAO.agregar(proveedores);
                  request.getRequestDispatcher("Controlador?menu=Proveedores&accion=Listar").forward(request, response);
                  break;
              case "Editar":
                  codProveedor = Integer.parseInt(request.getParameter("codigoProveedor"));
                  Proveedores p = proveedoresDAO.listarCodigoProveedor(codProveedor);
                  request.setAttribute("proveedorEncontrado", p);
                  request.getRequestDispatcher("Controlador?menu=Proveedores&accion=Listar").forward(request, response);
                  break;
              case "Actualizar":
                  String nombreProv = request.getParameter("txtNombres");
                  String telefonoProv = request.getParameter("txtTelefono");
                  String emailProv = request.getParameter("txtEmail");
                  proveedores.setNombreProveedor(nombreProv);
                  proveedores.setTelefonoProveedor(telefonoProv);
                  proveedores.setEmail(emailProv);
                  proveedores.setIdProveedor(codProveedor);
                  proveedoresDAO.actualizar(proveedores);
                  request.getRequestDispatcher("Controlador?menu=Proveedores&accion=Listar").forward(request, response);
                  break;
              case "Eliminar":
                  codProveedor = Integer.parseInt(request.getParameter("codigoDeProveedor"));
                  proveedoresDAO.eliminar(codProveedor);
                  request.getRequestDispatcher("Controlador?menu=Proveedores&accion=Listar").forward(request, response);
                  break;
          }
          request.getRequestDispatcher("Proveedores.jsp").forward(request, response);
      } else if (menu.equals("Cesta")) {
            switch (accion) {
                case "Listar":
                    List listaCesta = cestaDAO.listar();
                    request.setAttribute("cestas", listaCesta);
                    List listaUsuario = usuarioDAO.listar();
                    request.setAttribute("usuarios", listaUsuario);
                    break;
                case "Agregar":
                    int cantidadP; 
                    cantidadP= Integer.parseInt(request.getParameter("txtCantidad"));
                    String fechaC;
                    fechaC = request.getParameter("txtFecha");
                    java.sql.Date sqlDateC = java.sql.Date.valueOf(fechaC);
                    double subT;
                    subT = Double.parseDouble(request.getParameter("txtSubTotal"));
                    int idC;
                    idC = Integer.parseInt(request.getParameter("cmbIdUsuario"));
                    
                    cesta.setCantidad(cantidadP);
                    cesta.setFechaProducto(sqlDateC);
                    cesta.setSubTotal(subT);
                    cesta.setIdUsuario(idC);
                    cestaDAO.Agregar(cesta);
                    request.getRequestDispatcher("Controlador?menu=Cesta&accion=Listar").forward(request, response);
                    break;
                case "Editar":
                    idCesta=Integer.parseInt(request.getParameter("idCesta"));
                    Cesta c=cestaDAO.listarIdCesta(idCesta);
                    request.setAttribute("cestaEncontrada", c);
                    request.getRequestDispatcher("Controlador?menu=Cesta&accion=Listar").forward(request, response);
                    break;
                case "Actualizar":
                    int cantidad; 
                    cantidad= Integer.parseInt(request.getParameter("txtCantidad"));
                    String fecha;
                    fecha = request.getParameter("txtFecha");
                    java.sql.Date sqlDate = java.sql.Date.valueOf(fecha);
                    double sub;
                    sub = Double.parseDouble(request.getParameter("txtSubTotal"));
                    int id;
                    id = Integer.parseInt(request.getParameter("cmbIdUsuario"));
                    
                    cesta.setCantidad(cantidad);
                    cesta.setFechaProducto(sqlDate);
                    cesta.setSubTotal(sub);
                    cesta.setIdUsuario(id);
                    cesta.setIdCesta(idCesta);
                    cestaDAO.actualizar(cesta);
                    request.getRequestDispatcher("Controlador?menu=Cesta&accion=Listar").forward(request, response);
                    break;
                case "Eliminar":
                    idCesta = Integer.parseInt(request.getParameter("idCesta"));
                    cestaDAO.eliminar(idCesta);
                    request.getRequestDispatcher("Controlador?menu=Cesta&accion=Listar").forward(request, response);
                    break;
            }
            request.getRequestDispatcher("Cesta.jsp").forward(request, response);
        } else if (menu.equals("Resena")) {
            switch (accion) {
                case "Listar":
                    List listaResena = resenaDAO.listar();
                    request.setAttribute("resenas", listaResena);
                    List listaUsuario = usuarioDAO.listar();
                    request.setAttribute("usuarios", listaUsuario);
                    List listaProducto = productoDAO.listar();
                    request.setAttribute("productos", listaProducto);
                    break;
                case "Agregar":
                    Date fecha = (java.sql.Date.valueOf(request.getParameter("txtFecha")));
                    Integer calificacion = Integer.parseInt(request.getParameter("txtCalificacion"));
                    String resenaR = request.getParameter("txtResena");
                    int idUsuario;
                    idUsuario = Integer.parseInt(request.getParameter("txtIdUsuario"));
                    int idProducto;
                    idProducto = Integer.parseInt(request.getParameter("txtIdProducto"));
                    
                    resena.setFechaValoracion(new java.sql.Date(fecha.getTime()));
                    resena.setCalificacion(calificacion);
                    resena.setResena(resenaR);
                    resena.setIdUsuario(idUsuario);
                    resena.setIdProducto(idProducto);
                    resenaDAO.agregar(resena);
                    request.getRequestDispatcher("Controlador?menu=Resena&accion=Listar").forward(request, response);
                    break;
                case "Editar":
                    idResena = Integer.parseInt(request.getParameter("idResena"));
                    Resena r = resenaDAO.listarIdResena(idResena);
                    request.setAttribute("resenaEncontrada", r);
                    request.getRequestDispatcher("Controlador?menu=Resena&accion=Listar").forward(request, response);
                    break;
                case "Actualizar":
                    Date fechaRes = (java.sql.Date.valueOf(request.getParameter("txtFecha")));
                    Integer calificacionRes = Integer.parseInt(request.getParameter("txtCalificacion"));
                    String resenaRes = request.getParameter("txtResena");
                    resena.setFechaValoracion(new java.sql.Date(fechaRes.getTime()));
                    resena.setCalificacion(calificacionRes);
                    resena.setResena(resenaRes);
                    resena.setIdResena(idResena);
                    resenaDAO.actualizar(resena);
                    request.getRequestDispatcher("Controlador?menu=Resena&accion=Listar").forward(request, response);
                    break;
                case "Eliminar":
                    int idResena;
                    idResena = Integer.parseInt(request.getParameter("idResena"));
                    resenaDAO.eliminar(idResena);
                    request.getRequestDispatcher("Controlador?menu=Resena&accion=Listar").forward(request, response);
                    break;
            }
            request.getRequestDispatcher("Resena.jsp").forward(request, response);
        }else if (menu.equals("DetallePromocion")) {
            switch (accion) {
                case "Listar":
                    List listaDetallePromocioh = detallePromocionDAO.listar();
                    request.setAttribute("detallePromociones", listaDetallePromocioh);
                    List listaPromocion = promocionDao.listar();
                    request.setAttribute("promociones", listaPromocion);
                    List listaProducto = productoDAO.listar();
                    request.setAttribute("productos", listaProducto);
                    break;
                case "Agregar":
                    Double precioFinal = Double.parseDouble(request.getParameter("txtPrecioFinal"));
                    int idPromocion;
                    idPromocion = Integer.parseInt(request.getParameter("txtIdPromocion"));
                    int idProducto;
                    idProducto = Integer.parseInt(request.getParameter("txtIdProducto"));
                    
                    detallePromocion.setPrecioFinal(precioFinal);
                    detallePromocion.setIdPromocion(idPromocion);
                    detallePromocion.setIdProducto(idProducto);
                    detallePromocionDAO.agregar(detallePromocion);
                    request.getRequestDispatcher("Controlador?menu=DetallePromocion&accion=Listar").forward(request, response);
                    break;
                case "Editar":
                    idDetallePromocion = Integer.parseInt(request.getParameter("idDetallePromocion"));
                    DetallePromocion dp = detallePromocionDAO.listarIdDetallePromocion(idDetallePromocion);
                    request.setAttribute("detallePromocionEncontrado", dp);
                    request.getRequestDispatcher("Controlador?menu=DetallePromocion&accion=Listar").forward(request, response);
                    break;
                case "Actualizar":
                    Double precioFinalDP = Double.parseDouble(request.getParameter("txtPrecioFinal"));
                    detallePromocion.setPrecioFinal(precioFinalDP);
                    detallePromocion.setIdDetallePromocion(idDetallePromocion);
                    
                    break;
                case "Eliminar":
                    break;
            }
            request.getRequestDispatcher("DetallePromocion.jsp").forward(request, response);
        } else if (menu.equals("Promocion")) {
            switch (accion) {
                case "Listar":
                    List listaPromocion = promocionDao.listar();
                    request.setAttribute("promociones", listaPromocion);
                    break;
                case "Agregar":

                    break;
                case "Editar":

                    break;
                case "Actualizar":

                    break;
                case "Eliminar":

                    break;
            }

            request.getRequestDispatcher("Promocion.jsp").forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        int id = Integer.parseInt(request.getParameter("id"));
        usuarioDAO.listarImg(id, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
