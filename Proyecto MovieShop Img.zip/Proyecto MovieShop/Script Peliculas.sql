/*
	Fecha de creación: 05-07-2023
    
    Fechas de modificación: 10-07-2023
    
    Programador: James Sipac 2022133
*/

drop database if exists DBPeliculasIN5AV;

create database DBPeliculasIN5AV;

use DBPeliculasIN5AV;

create table Usuarios(
	idUsuario int not null auto_increment,
    nombreUsuario varchar(150) not null,
    apellidoUsuario varchar(150) not null,
    usuario varchar(150) not null,
    pass varchar(150) not null,
    email varchar(150) not null,
    fotoPerfil longblob,
	primary key PK_idUsuario(idUsuario)
);



create table TipoTarjeta(
	idTipoTarjeta int not null auto_increment,
    tipoTarjeta varchar(30),
    primary key PK_idTipoTarjeta(idTipoTarjeta)
);

create table Pago(
	idPago int not null auto_increment,
    cantidadAPagar double not null,
    idTipoTarjeta int not null,
    fechaPago date not null,
    idUsuario int not null,
    primary key PK_idPago(idPago),
    constraint FK_Pago_Usuarios foreign key(idUsuario)
		references Usuarios(idUsuario),
	constraint FK_Pago_TipoTarjeta foreign key(idTipoTarjeta)
		references TipoTarjeta(idTipoTarjeta)
);




create table Proveedores(
	idProveedor int not null auto_increment,
    nombreProveedor varchar(150) not null,
    telefonoProveedor varchar(150) not null,
    email varchar(150),
    primary key PK_idProveedor(idProveedor)
);

create table Producto(
	idProducto int not null auto_increment,
    nombreProducto varchar(150) not null,
	genero varchar(150) not null,
    categoria varchar(150) not null,
    precio double not null,
    duracion varchar(150) not null,
    sinopsis varchar(250) not null,
    portada longBlob,
    trailer varchar(150) not null,
    idProveedor int not null,
    primary key PK_idProducto(idProducto),
    constraint FK_Producto_Proveedores foreign key (idProveedor)
		references Proveedores(idProveedor)
);

create table Cesta(
	idCesta int not null auto_increment,
    cantidad int not null,
    fechaProducto date not null,
    subtotal double not null,
    idUsuario int not null,
    idProducto int not null,
    primary key PK_idCesta(idCesta),
    constraint FK_Cesta_Usuarios foreign key(idUsuario)
		references Usuarios(idUsuario),
	constraint FK_Cesta_Producto foreign key(idProducto)
		references Producto(idProducto)
);

create table Resena(
	idResena int not null auto_increment,
    fechaValoracion date not null,
    calificacion int,    
    resena varchar(250),
    idUsuario int not null,
    idProducto int not null,
    primary key PK_idResena(idResena),
    constraint FK_Resena_Usuarios foreign key(idUsuario)
		references Usuarios(idUsuario),
	constraint FK_Resena_Producto foreign key(idProducto)
		references Producto(idProducto)
);

create table ServicioCliente(
	idServicio int not null auto_increment,
    descripcion varchar(250),
    idUsuario int not null,
    idProducto int not null,
    primary key PK_idServicio(idServicio),
    constraint FK_ServicioCliente_Usuarios foreign key(idUsuario)
		references Usuarios(idUsuario),
	constraint FK_ServicioCliente_Producto foreign key(idProducto)
		references Producto(idProducto)
);

create table Promocion(
	idPromocion int not null auto_increment,
    porcentajePromocion int not null,
    fechaInicio datetime not null,
    fechaFinal datetime not null,
    primary key PK_idPromocion(idPromocion)
);

create table DetallePromocion(
	idDetallePromocion int not null auto_increment,
    precioFinal double not null,
    idPromocion int not null,
    idProducto int not null,
    primary key PK_idDetallePromocion(idDetallePromocion),
    constraint FK_DetallePromocion_Promocion foreign key(idPromocion)
		references Promocion(idPromocion),
	constraint FK_DetallePromocion_Producto foreign key(idProducto)
		references Producto(idProducto)
);

create table DetallePago(
	idDetallePago int not null auto_increment,
    cantidad int not null,
    idPago int not null,
    idCesta int not null,
    primary key PK_idDetallePago(idDetallePago),
	constraint FK_DetallePago_Pago foreign key(idPago)
		references Pago(idPago),
	constraint FK_DetallePago_Cesta foreign key(idCesta)
		references Cesta(idCesta)
);

-- ------------------ Ingreso de datos ----------------------------

Insert into Usuarios (nombreUsuario, apellidoUsuario, usuario, pass, email, fotoPerfil)
	values ('James Brian', 'Sipac Sipac', 'jsipac-2022133', 'sipac', 'jsipac-2022133@kinal.edu.gt','');
Insert into Usuarios (nombreUsuario, apellidoUsuario, usuario, pass, email, fotoPerfil)
	values ('Byron Fernando', 'Roquel Batzibal', 'broquel-2022168', 'roquel', 'broquel-2022168@kinal.edu.gt','');
Insert into Usuarios (nombreUsuario, apellidoUsuario, usuario, pass, email, fotoPerfil)
	values ('Rubén Darío', 'Paredes Flores', 'rparedes-2022088', 'paredes', 'rparedes-2022088@kinal.edu.gt','');
Insert into Usuarios (nombreUsuario, apellidoUsuario, usuario, pass, email, fotoPerfil)
	values ('Miguel David', 'Yac Castro', 'myac-2022020', 'yac', 'myac-2022020@kinal.edu.gt','');
Insert into Usuarios (nombreUsuario, apellidoUsuario, usuario, pass, email, fotoPerfil)
	values ('Joshua Elijhab', 'Rosselin Corzo', 'jrosselin-2022050', 'rosselin', 'jrosselin-2022050@kinal.edu.gt','');
Insert into Usuarios (nombreUsuario, apellidoUsuario, usuario, pass, email, fotoPerfil)
	values ('Josué Alejandro', 'Pérez Maas', 'jperez-2022076', 'perez', 'jperez-2022076@kinal.edu.gt','');
Insert into Usuarios (nombreUsuario, apellidoUsuario, usuario, pass, email, fotoPerfil)
	values ('Angel David', 'Bachac Peralta', 'abachac-2022051', 'bachac', 'abachac-2022051@kinal.edu.gt','');
Insert into Usuarios (nombreUsuario, apellidoUsuario, usuario, pass, email, fotoPerfil)
	values ('Sergio Eduardo', 'Tepaz Vela', 'stepaz-2022164', 'tepaz', 'stepaz-2022164@kinal.edu.gt','');
Insert into Usuarios (nombreUsuario, apellidoUsuario, usuario, pass, email, fotoPerfil)
	values ('Frederic Edmundo', 'Silvestre Ixén', 'fsilvestre-2022163', 'silvestre', 'fsilvestre-2022163@kinal.edu.gt','');
Insert into Usuarios (nombreUsuario, apellidoUsuario, usuario, pass, email, fotoPerfil)
	values ('Luis Armando', 'Reyes Orón', 'luis153', '12345', 'luisito@gmail.com','');
Insert into Usuarios (nombreUsuario, apellidoUsuario, usuario, pass, email, fotoPerfil)
	values ('Steven', 'Sicaján Rodriguez', 'stev456', 'contra', 'steven@gmail.com','');
    
    
    select * From Usuarios;
-- ----------------------------------------------------------------

insert into TipoTarjeta(tipoTarjeta)
	values('Debito');
insert into TipoTarjeta(tipoTarjeta)
	values('Credito');
insert into TipoTarjeta(tipoTarjeta)
	values('Regalo');
    
-- ----------------------------------------------------------------

Insert into Pago (cantidadAPagar, idTipoTarjeta, fechaPago, idUsuario)
	values(100.55, 1, '2023-03-25', 1);
Insert into Pago (cantidadAPagar, idTipoTarjeta, fechaPago, idUsuario)
	values(250.00, 1, '2023-06-09', 2);
select * from Pago;
-- ------------------------------------------------------------------

Insert into Proveedores (nombreProveedor, telefonoProveedor, email)
	values('Sony-Columbia', '87957894', 'spe_privacy@spe.sony.com');
Insert into Proveedores (nombreProveedor, telefonoProveedor, email)
	values('Disney', '9394357', 'disneyworld.com/dine');
    
-- -------------------------------------------------------------------

Insert into Producto (nombreProducto, genero, categoria, precio, duracion, sinopsis, portada, trailer, idProveedor)
	value('Spider-Man: Into the Spider-Verse', 'Animación, Superhéroe', 'Acción, ciencia Ficción', 100.55, '2h 16m',
    'Spider-Man: Into the Spider-Verse presenta a Miles Morales, un adolescente de Brooklyn, y las ilimitadas posibilidades 
    del Universo Spider-Man, donde más de uno puede llevar la máscara.','','https://youtu.be/oBmazlyP220?si=fxj2YShS152pdmM-', 1);

Insert into Producto (nombreProducto, genero, categoria, precio, duracion, sinopsis, portada, trailer, idProveedor)
	value("Venom", "SuperHéroes","Acción",100.00,"2h 14min","Eddie Brock está investigando a Carlton Drake, el célebre fundador de Life Foundation. Brock establece una simbiosis con un ente alienígena que le ofrece superpoderes.",
		"","https://www.youtube.com/watch?v=u9Mv98Gr5pY",2);
Insert into Producto (nombreProducto, genero, categoria, precio, duracion, sinopsis, portada, trailer, idProveedor)
	value("Avengers Endgame", "Aventura, Acción, Fantasía","Superhéroes",140.50,"3h 2min",
    "El universo está en ruinas debido a las acciones de Thanos, el Titán Loco. Con la ayuda de los aliados que quedaron, los Vengadores deberán reunirse una vez más para intentar detenerlo",
    "","https://youtu.be/znk2OICHbjY?si=wyrt7cpbHeEUJyo2", 1);
Insert into Producto (nombreProducto, genero, categoria, precio, duracion, sinopsis, portada, trailer, idProveedor)
	value("Black Adam","Aventura, Suspenso","Drama, Ciencia Ficción",125.00,"2h 5min", 
    "Unos arqueólogos liberan de su tumba a Black Adam, quien llevaba 5000 años preso tras haber recibido los poderes de los dioses.",
    "","https://www.youtube.com/watch?v=a1mcS4tKGNg", 2);
Insert into Producto (nombreProducto, genero, categoria, precio, duracion, sinopsis, portada, trailer, idProveedor)
	value("Project Power", "Superheroe","Acción, Crimen", 175.00, "1h 53min", 
    "Las vidas de un exsoldado, una adolescente y un policía se cruzan en Nueva Orleans mientras buscan al suministrador de una pastilla que otorga superpoderes temporales.",
    "","https://www.youtube.com/watch?v=fg6eDTYDKNg", 1);
Insert into Producto (nombreProducto, genero, categoria, precio, duracion, sinopsis, portada, trailer, idProveedor)
	value('Avatar: the way of water', 'Accion, drama, aventura, ciencia ficción', 'Thriller, Fantasia', 250.00, '3h 12m', 
    'Jake Sully y Ney tiri han formado una familia y hacen todo lo posible por permanecer juntos. 
    Sin embargo, deben abandonar su hogar y explorar las regiones de Pandora cuando una antigua amenaza reaparece.','','https://youtu.be/u0hxjdWG84k?si=GzWv_4XzHr4JHFJy', 2);


Select * from Producto;
-- ---------------------------------------------------------------------

Insert into Cesta (cantidad, fechaProducto, subtotal, idUsuario, idProducto)
	values(1, '2023-03-25', 100.55, 1, 1);
Insert into Cesta (cantidad, fechaProducto, subtotal, idUsuario, idProducto)
	values(1, '2023-05-09', 250.00, 2, 1);
    
-- ---------------------------------------------------------------------

Insert into Resena (fechaValoracion, calificacion, resena, idUsuario, idProducto)
	values('2020-07-15', 5, 'Una pelicula que realmente trata de manera inteligente a su audiencia, su historia es genial sin dejar de lado
     la animación y el arte que tiene, es una pelicula que vale totalmente la pena', 1, 1);
Insert into Resena (fechaValoracion, calificacion, resena, idUsuario, idProducto)
	values('2023-01-20', 4, 'Una pelicula que es buena aunque no supera a su antesesora, aunque con mayor presupuesto, el CGI de está
    entrega deja mucho que desear, llegando a parecer un videojuego en muchos momento, pero es muy disfrutable', 2, 2);

-- ---------------------------------------------------------------------

Insert into ServicioCliente (descripcion, idUsuario, idProducto)
	values('La pelicula no se me fue entregada en el plazo que establecio la plataforma', 1, 1);
Insert into ServicioCliente (descripcion, idUsuario, idProducto)
	values('El paquete en el que venía la pelicula llego dañado', 2, 2);

-- -------------------------------------------------------------------

Insert into Promocion (porcentajePromocion, fechaInicio, fechaFinal)
	values(25, '2023-06-03', '2023-06-17');
Insert into Promocion (porcentajePromocion, fechaInicio, fechaFinal)
	values(10, '2023-03-10', '2023-03-24');

-- -------------------------------------------------------------------

Insert into DetallePromocion (precioFinal, idPromocion, idProducto)
	values(75.41, 1, 1);
Insert into DetallePromocion (precioFinal, idPromocion, idProducto)
	values(225.00, 1, 1);

-- ---------------------------------------------------------------------

Insert into DetallePago(cantidad, idPago, idCesta)
	values(1, 1, 1);
Insert into DetallePago(cantidad, idPago, idCesta)
	values(1, 2, 2);


select * from TipoTarjeta;