package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class PromocionDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;

    
    public int agregar(Promocion prom){
        String sql = "Insert into Promocion (porcentajePromocion, fechaInicio, fechaFinal) values(?,?,?)";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, prom.getPorcentajePromocion());
            ps.setDate(2, prom.getFechaInicio());
            ps.setDate(3, prom.getFechaFinal());
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
    }
    
    
    public Promocion listarCodigoPromocion(int id){
        Promocion prom = new Promocion();
        String sql = "Select * from Promocion where idPromocion ="+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()) {
                prom.setIdPromocion(rs.getInt(1));
                prom.setPorcentajePromocion(rs.getInt(2));
                prom.setFechaInicio(rs.getDate(3));
                prom.setFechaFinal(rs.getDate(4));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return prom;
    }
    
    public int actualizar(Promocion prom) {
        String sql = "Update Promocion "
                + "set porcentajePromocion = ?, "
                + "fechaInicio = ?, "
                + "fechaFinal = ?"
                + "where idPromocion = ?";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, prom.getPorcentajePromocion());
            ps.setDate(2,prom.getFechaInicio());
            ps.setDate(3, prom.getFechaFinal());
            ps.setInt(4, prom.getIdPromocion());
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return resp;
    }
       
    
    public void eliminar(int id){
        String sql = "delete from Promocion where idPromocion = "+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        
            
    }
    
    
    public List listar(){
        String sql = "select * from Promocion";
        List<Promocion> listaPromocion = new ArrayList<>();
        try {
            con = cn.Conexion();
            ps = con.prepareCall(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Promocion promo = new Promocion();
                promo.setIdPromocion(rs.getInt(1));
                promo.setPorcentajePromocion(rs.getInt(2));
                promo.setFechaInicio(rs.getDate(3));
                promo.setFechaFinal(rs.getDate(4));
                listaPromocion.add(promo);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return listaPromocion;
    }
}
