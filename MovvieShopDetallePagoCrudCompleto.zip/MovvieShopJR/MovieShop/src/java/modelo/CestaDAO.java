package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CestaDAO {
    Conexion cn=new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    
// Listar
    public List listar(){
        String sql="Select * from Cesta";
        List<Cesta> listaCesta=new ArrayList<>();
        try {
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                Cesta c=new Cesta();
                c.setIdCesta(rs.getInt(1));
                c.setCantidad(rs.getInt(2));
                c.setFechaProducto(rs.getDate(3));
                c.setSubTotal(rs.getDouble(4));
                c.setIdUsuario(rs.getInt(5));
                listaCesta.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaCesta;
    }   
    
// Agregar
    public int Agregar( Cesta c){
        String sql="Insert into Cesta (cantidad, fechaProducto, subtotal, idUsuario)\n" +
"	values(?,?,?,?);";
        try {
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.setInt(1, c.getCantidad());
            ps.setDate(2,c.getFechaProducto());
            ps.setDouble(3, c.getSubTotal());
            ps.setInt(4, c.getIdUsuario());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();        
        }
        return resp;
    }
    
// Listar Por Id
    public Cesta listarIdCesta(int id){
        //instanciar objeto producto
        Cesta c=new Cesta();
        String sql="select * from Cesta where idCesta="+id;
        try {
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                c.setCantidad(rs.getInt(2));
                c.setFechaProducto(rs.getDate(3));
                c.setSubTotal(rs.getDouble(4));
                c.setIdUsuario(rs.getInt(5));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return c;
    }
    
// Actualizar
    public int actualizar(Cesta c){
        String sql="Update Cesta set cantidad=?, fechaProducto=?, subtotal=?, idUsuario=? where idCesta= ?";
        try {
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.setInt(1, c.getCantidad());
            ps.setDate(2, c.getFechaProducto());
            ps.setDouble(3, c.getSubTotal());
            ps.setInt(4, c.getIdUsuario());
            ps.setInt(5, c.getIdCesta());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resp;
    }
    
// Eliminar
    public void eliminar(int id){
        String sql="delete from Cesta where idCesta="+id;
        try {
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();        
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
