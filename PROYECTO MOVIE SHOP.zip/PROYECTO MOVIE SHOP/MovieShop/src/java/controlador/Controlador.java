
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import modelo.Cesta;
import modelo.CestaDAO;
import modelo.DetallePago;
import modelo.DetallePagoDAO;
import modelo.DetallePromocion;
import modelo.DetallePromocionDAO;
import modelo.Pago;
import modelo.PagoDAO;
import modelo.Producto;
import modelo.ProductoDAO;
import modelo.Promocion;
import modelo.PromocionDAO;
import modelo.Proveedores;
import modelo.ProveedoresDAO;
import modelo.Resena;
import modelo.ResenaDAO;
import modelo.ServicioCliente;
import modelo.ServicioClienteDAO;
import modelo.TipoTarjeta;
import modelo.TipoTarjetaDAO;
import modelo.Usuario;
import modelo.UsuarioDAO;

/**
 *
 * @author 50242
 */
@WebServlet(name = "Controlador", urlPatterns = {"/Controlador"})
@MultipartConfig
public class Controlador extends HttpServlet {
    
    int idProducto;

    Usuario usuario = new Usuario();
    UsuarioDAO usuarioDAO = new UsuarioDAO();
    int idUsuario;
    Promocion promocion = new Promocion();
    PromocionDAO promocionDao = new PromocionDAO();
    Cesta cesta = new Cesta();
    CestaDAO cestaDAO = new CestaDAO();
    Resena resena = new Resena();
    ResenaDAO resenaDAO = new ResenaDAO();
    DetallePromocion detallePromocion = new DetallePromocion();
    DetallePromocionDAO detallePromocionDAO = new DetallePromocionDAO();
    Producto producto = new Producto();
    ProductoDAO productoDAO = new ProductoDAO();
    Pago pago = new Pago();
    PagoDAO pagoDAO = new PagoDAO();
    TipoTarjeta tipoTarjeta = new TipoTarjeta();
    TipoTarjetaDAO tipoTarjetaDAO = new TipoTarjetaDAO();
    DetallePago detallePago = new DetallePago();
    DetallePagoDAO detallePagoDao = new DetallePagoDAO();
    ServicioCliente servicioCliente = new ServicioCliente();
    ServicioClienteDAO servicioClienteDAO = new ServicioClienteDAO();
    Proveedores proveedores = new Proveedores();
    ProveedoresDAO proveedoresDAO = new ProveedoresDAO();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");

        if (menu.equals("PrincipalAdmin")) {
            request.getRequestDispatcher("PrincipalAdmin.jsp").forward(request, response);
        } else if (menu.equals("Index")) {
            request.getRequestDispatcher("index.jsp").forward(request, response);
        } else if (menu.equals("AgregarUsuarios")) {
            request.getRequestDispatcher("AgregarUsuarios.jsp").forward(request, response);
        } else if (menu.equals("Facebook")) {
            request.getRequestDispatcher("Facebook.jsp").forward(request, response);
        } else if (menu.equals("Google")) {
            request.getRequestDispatcher("Google.jsp").forward(request, response);
        } else if (menu.equals("Principal")) {
            request.getRequestDispatcher("Principal.jsp").forward(request, response);
        } else if (menu.equals("Peliculas")) {
            request.getRequestDispatcher("Peliculas.jsp").forward(request, response);
        } else if (menu.equals("Usuario")) {
            switch (accion) {
                case "Listar":
                    List listaUsuario = usuarioDAO.listar();
                    request.setAttribute("usuarios", listaUsuario);
                    break;
                case "Agregar":
                    String nombreUsuario = request.getParameter("txtNombres");
                    String apellidoUsuario = request.getParameter("txtApellidos");
                    String usua = request.getParameter("txtUsuario");
                    String pass = request.getParameter("txtPass");
                    String email = request.getParameter("txtEmail");
                    Part part = request.getPart("imgFotoPerfil");
                    InputStream inputStream = part.getInputStream();
                    usuario.setNombreUsuario(nombreUsuario);
                    usuario.setApellidoUsuario(apellidoUsuario);
                    usuario.setUsuario(usua);
                    usuario.setPass(pass);
                    usuario.setEmail(email);
                    usuario.setFotoPerfil(inputStream);
                    usuarioDAO.Agregar(usuario);
                    break;
                case "Editar":

                    break;
                case "Actualizar":

                    break;
                case "Eliminar":

                    break;
            }
            request.getRequestDispatcher("index.jsp").forward(request, response);

        } else if (menu.equals("Producto")) {
            switch (accion) {
                case "Listar":
                    List<Producto> listaProducto = productoDAO.listar();
                    request.setAttribute("productos", listaProducto);
                    List listaDeProveedores = proveedoresDAO.listar();
                    request.setAttribute("proveedores", listaDeProveedores);
                    /*List listaProveedor=productoDAO.listarProveedores();
                    request.setAttribute("proveedores", listaProveedor);*/
                    break;
                case "Agregar":
                    //System.out.println("Hola James");                    
                    String nombreProducto = request.getParameter("txtNombreProducto");
                    String genero = request.getParameter("txtGenero");
                    String categoria = request.getParameter("txtCategoria");
                    Double precio = Double.parseDouble(request.getParameter("txtPrecio"));
                    String duracion = request.getParameter("txtDuracion");
                    String sinopsis = request.getParameter("txtSinopsis");
                    Part part = request.getPart("imgPortada");
                    InputStream inputStream = part.getInputStream();
                    int idProveedor;
                    idProveedor = Integer.parseInt(request.getParameter("cmbIdProveedor"));

                    producto.setNombreProducto(nombreProducto);
                    producto.setGenero(genero);
                    producto.setCategoria(categoria);
                    producto.setPrecio(precio);
                    producto.setDuracion(duracion);
                    producto.setSinopsis(sinopsis);
                    producto.setPortada(inputStream);
                    producto.setIdProveedor(idProveedor);
                    productoDAO.agregar(producto);
                    
                    request.getRequestDispatcher("Controlador?menu=Producto&accion=Listar").forward(request, response);
                    break;
                case "Editar":
                    idProducto = Integer.parseInt(request.getParameter("idProducto"));
                    Producto p = productoDAO.listarIdProducto(idProducto);
                    request.setAttribute("productoEncontrado", p);
                    request.getRequestDispatcher("Controlador?menu=Producto&accion=Listar").forward(request, response);
                    break;
                case "Actualizar":
                    System.out.println("Hola");
                    
                    String nombreProd = request.getParameter("txtNombreProducto");
                    String generoProd = request.getParameter("txtGenero");
                    String categoriaProd = request.getParameter("txtCategoria");
                    Double precioProd = Double.parseDouble(request.getParameter("txtPrecio"));
                    String duracionProd = request.getParameter("txtDuracion");
                    String sinopsisProd = request.getParameter("txtSinopsis");
                    Part partProd = request.getPart("imgPortada");
                    InputStream inputStreamProd = partProd.getInputStream();
                    int idProveedorProd;
                    idProveedorProd = Integer.parseInt(request.getParameter("cmbIdProveedor"));

                    producto.setNombreProducto(nombreProd);
                    producto.setGenero(generoProd);
                    producto.setCategoria(categoriaProd);
                    producto.setPrecio(precioProd);
                    producto.setDuracion(duracionProd);
                    producto.setSinopsis(sinopsisProd);
                    producto.setPortada(inputStreamProd);
                    producto.setIdProveedor(idProveedorProd);
                    producto.setIdProducto(idProducto);                    
                    productoDAO.actualizar(producto);
                    
                   /* System.out.println(nombreProd);
                    System.out.println(generoProd);
                    System.out.println(categoriaProd);
                    System.out.println(precioProd);
                    System.out.println(duracionProd);
                    System.out.println(sinopsisProd);
                    System.out.println(inputStreamProd);
                    System.out.println(idProveedorProd);
                    System.out.println(idProducto);*/
                    
                    request.getRequestDispatcher("Controlador?menu=Producto&accion=Listar").forward(request, response);
                    
                    break;
                case "Eliminar":
                    idProducto = Integer.parseInt(request.getParameter("idProducto"));
                    productoDAO.eliminar(idProducto);
                    request.getRequestDispatcher("Controlador?menu=Producto&accion=Listar").forward(request, response);

                    break;
            }
            request.getRequestDispatcher("Producto.jsp").forward(request, response);

        } else if (menu.equals("DetallePago")) {
            switch (accion) {
                case "Listar":
                    List litaDetallePagos = detallePagoDao.listar();
                    request.setAttribute("detallePagos", litaDetallePagos);
                    break;
                case "Agregar":

                    break;
                case "Editar":

                    break;
                case "Actualizar":

                    break;
                case "Eliminar":

                    break;
            }

            request.getRequestDispatcher("DetallePago.jsp").forward(request, response);

        } else if (menu.equals("Pago")) {
            switch (accion) {
                case "Listar":
                    List listaPago = pagoDAO.listar();
                    request.setAttribute("pagos", listaPago);
                    break;
                case "Agregar":

                    break;
                case "Editar":

                    break;
                case "Actualizar":

                    break;
                case "Eliminar":

                    break;
            }
            request.getRequestDispatcher("Pago.jsp").forward(request, response);

        } else if (menu.equals("TipoTarjeta")) {
            switch (accion) {
                case "Listar":
                    List listaTipoTarjeta = tipoTarjetaDAO.listar();
                    request.setAttribute("tipoTarjetas", listaTipoTarjeta);
                    break;
                case "Agregar":

                    break;
                case "Editar":

                    break;
                case "Actualizar":

                    break;
                case "Eliminar":

                    break;
            }
            request.getRequestDispatcher("TipoTarjeta.jsp").forward(request, response);

        } else if (menu.equals("ServicioCliente")) {
            switch (accion) {
                case "Listar":
                    List listarServicioCliente = servicioClienteDAO.listar();
                    request.setAttribute("servicioClientes", listarServicioCliente);
                    break;
                case "Agregar":

                    break;
                case "Editar":

                    break;
                case "Actualizar":

                    break;
                case "Eliminar":

                    break;
            }
            request.getRequestDispatcher("TablaServicioCliente.jsp").forward(request, response);

        } else if (menu.equals("Proveedores")) {
            switch (accion) {
                case "Listar":
                    List listaDeProveedores = proveedoresDAO.listar();
                    request.setAttribute("proveedores", listaDeProveedores);
                    break;
                case "Agregar":
                    break;
                case "Editar":
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
            }
            request.getRequestDispatcher("Proveedores.jsp").forward(request, response);
        } else if (menu.equals("Cesta")) {
            switch (accion) {
                case "Listar":
                    List listaCesta = cestaDAO.listar();
                    request.setAttribute("cestas", listaCesta);
                    break;
            }
            request.getRequestDispatcher("Cesta.jsp").forward(request, response);
        } else if (menu.equals("Resena")) {
            switch (accion) {
                case "Listar":
                    List listaResena = resenaDAO.listar();
                    request.setAttribute("resenas", listaResena);
                    break;
                case "Agregar":
                    break;
                case "Editar":
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
            }
            request.getRequestDispatcher("Resena.jsp").forward(request, response);
        } else if (menu.equals("DetallePromocion")) {
            switch (accion) {
                case "Listar":
                    List listaDetallePromocioh = detallePromocionDAO.listar();
                    request.setAttribute("detallePromociones", listaDetallePromocioh);
                    break;
                case "Agregar":
                    break;
                case "Editar":
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
            }
            request.getRequestDispatcher("DetallePromocion.jsp").forward(request, response);
        } else if (menu.equals("Promocion")) {
            switch (accion) {
                case "Listar":
                    List listaPromocion = promocionDao.listar();
                    request.setAttribute("promociones", listaPromocion);
                    break;
                case "Agregar":

                    break;
                case "Editar":

                    break;
                case "Actualizar":

                    break;
                case "Eliminar":

                    break;
            }

            request.getRequestDispatcher("Promocion.jsp").forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        int id = Integer.parseInt(request.getParameter("id"));
        usuarioDAO.listarImg(id, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
