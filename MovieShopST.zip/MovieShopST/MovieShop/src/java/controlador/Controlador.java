/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Cesta;
import modelo.CestaDAO;
import modelo.DetallePago;
import modelo.DetallePagoDAO;
import modelo.DetallePromocion;
import modelo.DetallePromocionDAO;
import modelo.Producto;
import modelo.ProductoDAO;
import modelo.Proveedores;
import modelo.ProveedoresDAO;
import modelo.Resena;
import modelo.ResenaDAO;

/**
 *
 * @author SIPAC
 */
@WebServlet(name = "Controlador", urlPatterns = {"/Controlador"})
public class Controlador extends HttpServlet {
    Producto producto=new Producto();
    ProductoDAO productoDao=new ProductoDAO();
    
    DetallePago detallePago = new DetallePago();
    DetallePagoDAO detallePagoDao = new DetallePagoDAO();
    
    Proveedores proveedores = new Proveedores();
    ProveedoresDAO proveedoresDao = new ProveedoresDAO();
    
    Cesta cesta = new Cesta();
    CestaDAO cestaDao = new CestaDAO();
    
    Resena resena =  new Resena();
    ResenaDAO resenaDAO = new ResenaDAO();
    DetallePromocion detallePromocion = new DetallePromocion();
    DetallePromocionDAO detallePromocionDAO = new DetallePromocionDAO();
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
     String menu=request.getParameter("menu");
     String accion=request.getParameter("accion");
     if(menu.equals("Principal")){
         request.getRequestDispatcher("Principal.jsp").forward(request, response);
         
     }else if(menu.equals("Producto")){
         switch(accion){
             case "Listar":
                 List listaProducto=productoDao.listar();
                 request.setAttribute("productos", listaProducto);
                 break;
             case "Agregar":
                 break;
             case "Editar":
                 break;
             case "Actualizar":
                 break;
             case "Eliminar":
                 break;
         }
         request.getRequestDispatcher("Producto.jsp").forward(request, response);
     }else if(menu.equals("DetallePago")){
          switch(accion){
              case "Listar":
                  List litaDetallePagos = detallePagoDao.listar();
                  request.setAttribute("detallePagos", litaDetallePagos);
                  break;
              case "Agregar":
                  
                  break;
              case "Editar":
                  
                  break;
              case "Actualizar":
                  
                  break;
              case "Eliminar":
                  
                  break;
          }
          
          request.getRequestDispatcher("DetallePago.jsp").forward(request, response);
      }else if(menu.equals("Proveedores")){
          switch(accion){
              case "Listar":
                  List listaDeProveedores = proveedoresDao.listar();
                  request.setAttribute("proveedores", listaDeProveedores);
                  break;
              case "Agregar":
                  break;
              case "Editar":
                  break;
              case "Actualizar":
                  break;
              case "Eliminar":
                  break;
          }
          request.getRequestDispatcher("Proveedores.jsp").forward(request, response);
      }else if(menu.equals("Cesta")){
                switch(accion){
                case "Listar":
                    List listaCesta = cestaDao.listar();
                    request.setAttribute("cestas", listaCesta);
                    break;
                }
                request.getRequestDispatcher("Cesta.jsp").forward(request, response);
      }else if(menu.equals("Resena")){
         switch(accion){
             case "Listar":
                 List listaResena = resenaDAO.listar();
                 request.setAttribute("resenas", listaResena);
                 break;
             case "Agregar":
                 break;
             case "Editar":
                 break;
             case "Actualizar":
                 break;
             case "Eliminar":
                 break;
         }
         request.getRequestDispatcher("Resena.jsp").forward(request, response);
     } else if (menu.equals("DetallePromocion")) {
            switch(accion){
             case "Listar":
                 List listaDetallePromocioh = detallePromocionDAO.listar();
                 request.setAttribute("detallePromociones", listaDetallePromocioh);
                 break;
             case "Agregar":
                 break;
             case "Editar":
                 break;
             case "Actualizar":
                 break;
             case "Eliminar":
                 break;
         }
         request.getRequestDispatcher("DetallePromocion.jsp").forward(request, response);
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    
}
